let horas = 0
let minutos = 0
let segundos = 0
let msegundos = 0

let timerV = false

let mostrar = ()=>{
    document.getElementById('counter').innerHTML = segundos + '.' + msegundos
}


let reset = () =>{

    timerV = false
    segundos = 0
    msegundos = 0

}


let timer = setInterval(() =>{
  
    if(timerV === true){
        msegundos +=1
    
        if(msegundos>=60){
            segundos+=1
            msegundos = 0
        }
        
        
    }

    mostrar() 
 }, 10)
   
 
